#ifndef ARROWITEM_H
#define ARROWITEM_H

#include <QDeclarativeItem>

class ArrowItem : public QDeclarativeItem
{
    Q_OBJECT

    Q_PROPERTY(bool wheelRotation READ wheelRotation WRITE setWheelRotation NOTIFY wheelRotationChanged)
    Q_PROPERTY(QColor color READ color WRITE setColor NOTIFY colorChanged)

public:
    explicit ArrowItem(QDeclarativeItem *parent = 0);

    bool wheelRotation() const;
    void setWheelRotation(bool enabled);

    QColor color() const;
    void setColor(const QColor &color);

    virtual void paint(QPainter *, const QStyleOptionGraphicsItem *, QWidget * = 0);

signals:
    void wheelRotationChanged(bool);
    void colorChanged(const QColor &color);

protected:
    virtual void wheelEvent(QGraphicsSceneWheelEvent *event);

private:
    int m_rotationAngle;
    bool m_wheelRotation;
    QColor m_color;
};

#endif // ARROWITEM_H
