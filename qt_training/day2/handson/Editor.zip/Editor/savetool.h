#ifndef SAVETOOL_H
#define SAVETOOL_H

#include <QObject>

class QGraphicsScene;

class SaveTool : public QObject
{
    Q_OBJECT
public:
    SaveTool(QGraphicsScene *scene, QObject *parent = 0);

signals:

public slots:
    void save();

private:
    QGraphicsScene *m_scene;
};

#endif // SAVETOOL_H
