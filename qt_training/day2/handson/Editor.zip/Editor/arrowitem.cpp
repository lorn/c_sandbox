#include "arrowitem.h"

#include <QGraphicsSceneWheelEvent>
#include <QPainter>
#include <QPen>

ArrowItem::ArrowItem(QDeclarativeItem *parent) :
    QDeclarativeItem(parent), m_rotationAngle(0), m_wheelRotation(false), m_color(Qt::black)
{
    setFlag(QGraphicsItem::ItemHasNoContents, false);
}

bool ArrowItem::wheelRotation() const
{
    return m_wheelRotation;
}

void ArrowItem::setWheelRotation(bool enabled)
{
    if (m_wheelRotation == enabled)
        return;

    m_wheelRotation = enabled;
    emit wheelRotationChanged(enabled);
}

QColor ArrowItem::color() const
{
    return m_color;
}

void ArrowItem::setColor(const QColor &color)
{
    if (m_color == color)
        return;

    m_color = color;
    emit colorChanged(color);
}

void ArrowItem::paint(QPainter *p, const QStyleOptionGraphicsItem *, QWidget *)
{
    QRectF br = boundingRect();
    int length = qMin(br.width(), br.height()) - 10;

    p->save();
    p->setPen(QPen(m_color, 4));
    p->setRenderHints(QPainter::Antialiasing, true);
    p->translate(br.center());
    p->rotate(m_rotationAngle);
    p->drawLine(-length/2, 0, length/2, 0);
    p->translate(length/2, 0);
    p->rotate(45);
    p->drawLine(-10, 0, 0, 0);
    p->rotate(-90);
    p->drawLine(-10, 0, 0, 0);
    p->restore();
}

void ArrowItem::wheelEvent(QGraphicsSceneWheelEvent *event)
{
    if (m_wheelRotation) {
        m_rotationAngle = (m_rotationAngle + event->delta() / 4) % 360;
        update();
    }
}
