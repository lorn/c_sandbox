#include "savetool.h"

#include <QFileDialog>
#include <QGraphicsScene>
#include <QImage>
#include <QPainter>

SaveTool::SaveTool(QGraphicsScene *scene, QObject *parent) :
    QObject(parent), m_scene(scene)
{

}

void SaveTool::save()
{
    QImage image(QSize(800, 600), QImage::Format_ARGB32);
    QPainter p(&image);
    m_scene->render(&p);
    p.end();

    image.save(QFileDialog::getSaveFileName());
}
