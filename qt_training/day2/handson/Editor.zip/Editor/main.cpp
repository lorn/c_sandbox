#include <QApplication>
#include <QDeclarativeContext>
#include <QDeclarativeView>

#include "arrowitem.h"
#include "savetool.h"

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);

    qmlRegisterType<ArrowItem>("Utils", 1, 0, "ArrowItem");

    QDeclarativeView view;

    SaveTool saveTool(view.scene());
    view.rootContext()->setContextProperty("saveTool", &saveTool);

    view.setSource(QUrl("qrc:/ui/main.qml"));
    view.show();

    return app.exec();
}
